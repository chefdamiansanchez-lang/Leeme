# Lector de Voz

App de Android (Kotlin) que busca libros en el dispositivo (.txt, .epub, .pdf)
y los lee en voz alta en español, funcionando en segundo plano y recordando
en qué parte de cada libro te quedaste.

## Funciones
- Escanea el almacenamiento del dispositivo buscando libros en formato TXT, EPUB y PDF.
- Lee el contenido en voz alta usando el sintetizador de voz nativo de Android (TextToSpeech) en español.
- Notificación permanente mientras lee, mostrando el título y un fragmento del texto actual (con botones para pausar/detener desde ahí también se puede seguir ampliando).
- Sigue leyendo aunque se apague la pantalla o se cambie de app (servicio en primer plano).
- Guarda automáticamente el punto exacto de lectura (por libro) para continuar después sin volver a empezar.

## Cómo abrir el proyecto
1. Instalá [Android Studio](https://developer.android.com/studio) (versión reciente, con SDK 34).
2. Descomprimí este .zip.
3. En Android Studio: **File → Open** y seleccioná la carpeta descomprimida.
4. Dejá que Gradle sincronice (la primera vez descarga dependencias, necesita internet).
5. Conectá un dispositivo o usá un emulador y tocá **Run**.

## Compilación automática (genera el APK descargable solo)
Este proyecto incluye `.github/workflows/build-apk.yml`. Al subir el zip a un
repositorio en GitHub, se dispara solo y arma el APK, que después queda para
descargar en la pestaña **Actions** (como artifact) y también en **Releases**.
No hace falta hacer nada más que subir el zip.

## Subir a GitHub
```bash
cd lector-voz-app
git init
git add .
git commit -m "Primera versión de Lector de Voz"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git push -u origin main
```

## Permisos que pide la app
- Acceso a todos los archivos (para poder encontrar libros en cualquier carpeta).
- Notificaciones (para mostrar el estado de la lectura).
En el primer inicio te va a llevar a la pantalla de Ajustes para habilitar el
acceso a archivos (obligatorio en Android 11 o superior).

## Cómo sigue creciendo
Ideas para las próximas versiones, por si querés que sigamos:
- Resaltar la frase exacta que se está leyendo dentro del texto.
- Elegir voz/velocidad de lectura desde la app.
- Detectar automáticamente portada y autor en los EPUB.
- Modo oscuro/claro y ajustes de tamaño de letra.
