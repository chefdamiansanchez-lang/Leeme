package com.usuario.lectorvoz

data class Book(
    val path: String,
    val title: String,
    val format: String // "txt", "epub" o "pdf"
)
