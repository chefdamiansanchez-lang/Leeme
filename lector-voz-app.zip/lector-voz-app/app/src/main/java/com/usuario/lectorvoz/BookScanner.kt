package com.usuario.lectorvoz

import android.os.Environment
import java.io.File

object BookScanner {

    private val extensiones = setOf("txt", "epub", "pdf")

    fun buscarLibros(): List<Book> {
        val raiz = Environment.getExternalStorageDirectory()
        val encontrados = mutableListOf<Book>()
        buscarRecursivo(raiz, encontrados, 0)
        return encontrados.sortedBy { it.title.lowercase() }
    }

    private fun buscarRecursivo(dir: File, out: MutableList<Book>, profundidad: Int) {
        // Limitamos la profundidad para no tardar demasiado ni entrar en carpetas del sistema
        if (profundidad > 6) return
        val archivos = dir.listFiles() ?: return
        for (archivo in archivos) {
            if (archivo.isDirectory) {
                if (archivo.name.startsWith(".")) continue
                if (archivo.name == "Android") continue
                buscarRecursivo(archivo, out, profundidad + 1)
            } else {
                val ext = archivo.extension.lowercase()
                if (ext in extensiones && archivo.length() > 0) {
                    out.add(
                        Book(
                            path = archivo.absolutePath,
                            title = archivo.nameWithoutExtension,
                            format = ext
                        )
                    )
                }
            }
        }
    }
}
