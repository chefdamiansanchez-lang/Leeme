package com.usuario.lectorvoz

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var textVacio: TextView

    private val codigoPermisoLegacy = 100
    private val codigoPermisoNotif = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.recyclerLibros)
        textVacio = findViewById(R.id.textVacio)
        recycler.layoutManager = LinearLayoutManager(this)

        pedirPermisosNecesarios()
    }

    override fun onResume() {
        super.onResume()
        if (tienePermisoDeArchivos()) {
            cargarLibros()
        }
    }

    private fun tienePermisoDeArchivos(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.os.Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    private fun pedirPermisosNecesarios() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), codigoPermisoNotif
                )
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!android.os.Environment.isExternalStorageManager()) {
                Toast.makeText(this, getString(R.string.permiso_necesario), Toast.LENGTH_LONG).show()
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                codigoPermisoLegacy
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == codigoPermisoLegacy && tienePermisoDeArchivos()) {
            cargarLibros()
        }
    }

    private fun cargarLibros() {
        Thread {
            val libros = BookScanner.buscarLibros()
            runOnUiThread {
                if (libros.isEmpty()) {
                    textVacio.visibility = TextView.VISIBLE
                } else {
                    textVacio.visibility = TextView.GONE
                }
                recycler.adapter = BookAdapter(libros) { libro ->
                    abrirLector(libro)
                }
            }
        }.start()
    }

    private fun abrirLector(libro: Book) {
        val intent = Intent(this, ReaderActivity::class.java)
        intent.putExtra(ReadingService.EXTRA_PATH, libro.path)
        intent.putExtra(ReadingService.EXTRA_TITULO, libro.title)
        intent.putExtra(ReadingService.EXTRA_FORMATO, libro.format)
        startActivity(intent)
    }
}
