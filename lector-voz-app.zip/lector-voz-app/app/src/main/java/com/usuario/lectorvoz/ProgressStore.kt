package com.usuario.lectorvoz

import android.content.Context

/**
 * Guarda en qué fragmento de cada libro se quedó el usuario, para poder
 * continuar exactamente donde lo dejó sin volver a empezar.
 */
object ProgressStore {

    private const val PREFS = "lector_voz_progreso"

    private fun clave(bookPath: String) = "frag_" + bookPath.hashCode()

    fun guardarProgreso(context: Context, bookPath: String, indiceFragmento: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(clave(bookPath), indiceFragmento).apply()
    }

    fun obtenerProgreso(context: Context, bookPath: String): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getInt(clave(bookPath), 0)
    }

    fun guardarUltimoLibro(context: Context, bookPath: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString("ultimo_libro", bookPath).apply()
    }

    fun obtenerUltimoLibro(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString("ultimo_libro", null)
    }
}
