package com.usuario.lectorvoz

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import android.widget.Button
import android.widget.TextView

/**
 * Pantalla del lector: muestra qué se está leyendo en este momento y
 * permite reproducir, pausar o detener. El trabajo real lo hace ReadingService
 * en segundo plano, así que la lectura sigue aunque se salga de esta pantalla.
 */
class ReaderActivity : AppCompatActivity() {

    private lateinit var textTitulo: TextView
    private lateinit var textProgreso: TextView
    private lateinit var textContenido: TextView

    private lateinit var bookPath: String
    private lateinit var bookTitulo: String
    private lateinit var bookFormato: String

    private val receptorProgreso = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val actual = intent.getIntExtra(ReadingService.EXTRA_FRAGMENTO_ACTUAL, 0)
            val total = intent.getIntExtra(ReadingService.EXTRA_TOTAL_FRAGMENTOS, 0)
            val texto = intent.getStringExtra(ReadingService.EXTRA_TEXTO_FRAGMENTO) ?: ""
            textProgreso.text = if (total > 0) "Parte ${actual + 1} de $total" else "Cargando…"
            if (texto.isNotBlank()) {
                textContenido.text = texto
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reader)

        textTitulo = findViewById(R.id.textTituloLibro)
        textProgreso = findViewById(R.id.textProgreso)
        textContenido = findViewById(R.id.textContenido)

        bookPath = intent.getStringExtra(ReadingService.EXTRA_PATH) ?: ""
        bookTitulo = intent.getStringExtra(ReadingService.EXTRA_TITULO) ?: "Libro"
        bookFormato = intent.getStringExtra(ReadingService.EXTRA_FORMATO) ?: "txt"

        textTitulo.text = bookTitulo

        findViewById<Button>(R.id.btnReproducir).setOnClickListener { iniciarLectura() }
        findViewById<Button>(R.id.btnPausar).setOnClickListener { enviarAccion(ReadingService.ACTION_PAUSAR) }
        findViewById<Button>(R.id.btnDetener).setOnClickListener { enviarAccion(ReadingService.ACTION_DETENER) }
    }

    override fun onStart() {
        super.onStart()
        LocalBroadcastManager.getInstance(this).registerReceiver(
            receptorProgreso, IntentFilter(ReadingService.BROADCAST_PROGRESO)
        )
    }

    override fun onStop() {
        super.onStop()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receptorProgreso)
    }

    private fun iniciarLectura() {
        val intent = Intent(this, ReadingService::class.java).apply {
            action = ReadingService.ACTION_START
            putExtra(ReadingService.EXTRA_PATH, bookPath)
            putExtra(ReadingService.EXTRA_TITULO, bookTitulo)
            putExtra(ReadingService.EXTRA_FORMATO, bookFormato)
        }
        ContextCompat.startForegroundService(this, intent)
        textProgreso.text = "Cargando…"
    }

    private fun enviarAccion(accion: String) {
        val intent = Intent(this, ReadingService::class.java).apply { action = accion }
        ContextCompat.startForegroundService(this, intent)
    }
}
