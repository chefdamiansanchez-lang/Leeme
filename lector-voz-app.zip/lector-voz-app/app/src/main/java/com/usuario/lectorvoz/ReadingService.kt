package com.usuario.lectorvoz

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.util.Locale

/**
 * Servicio en primer plano que hace la lectura en voz alta.
 * Sigue funcionando aunque la app pase a segundo plano o se apague la pantalla,
 * y guarda el progreso constantemente para poder retomar la lectura después.
 */
class ReadingService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.usuario.lectorvoz.action.START"
        const val ACTION_PAUSAR = "com.usuario.lectorvoz.action.PAUSAR"
        const val ACTION_REANUDAR = "com.usuario.lectorvoz.action.REANUDAR"
        const val ACTION_DETENER = "com.usuario.lectorvoz.action.DETENER"

        const val EXTRA_PATH = "extra_path"
        const val EXTRA_TITULO = "extra_titulo"
        const val EXTRA_FORMATO = "extra_formato"

        const val BROADCAST_PROGRESO = "com.usuario.lectorvoz.PROGRESO"
        const val EXTRA_FRAGMENTO_ACTUAL = "extra_fragmento_actual"
        const val EXTRA_TOTAL_FRAGMENTOS = "extra_total_fragmentos"
        const val EXTRA_TEXTO_FRAGMENTO = "extra_texto_fragmento"
        const val EXTRA_REPRODUCIENDO = "extra_reproduciendo"

        private const val CANAL_ID = "lector_voz_canal"
        private const val NOTIF_ID = 1
    }

    private var tts: TextToSpeech? = null
    private var ttsListo = false

    private var bookPath: String = ""
    private var bookTitulo: String = ""
    private var bookFormato: String = ""

    private var fragmentos: List<String> = emptyList()
    private var indiceActual: Int = 0
    private var reproduciendo: Boolean = false

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        crearCanalNotificacion()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                bookPath = intent.getStringExtra(EXTRA_PATH) ?: return START_NOT_STICKY
                bookTitulo = intent.getStringExtra(EXTRA_TITULO) ?: "Libro"
                bookFormato = intent.getStringExtra(EXTRA_FORMATO) ?: "txt"
                iniciarNotificacionYExtraccion()
            }
            ACTION_PAUSAR -> pausar()
            ACTION_REANUDAR -> reanudar()
            ACTION_DETENER -> detener()
        }
        return START_STICKY
    }

    private fun iniciarNotificacionYExtraccion() {
        startForeground(NOTIF_ID, construirNotificacion("Cargando libro…"))
        Thread {
            val book = Book(bookPath, bookTitulo, bookFormato)
            val texto = try {
                TextExtractor.extraerTexto(applicationContext, book)
            } catch (e: Exception) {
                ""
            }
            fragmentos = TextExtractor.dividirEnFragmentos(texto)
            indiceActual = ProgressStore.obtenerProgreso(applicationContext, bookPath)
                .coerceIn(0, (fragmentos.size - 1).coerceAtLeast(0))
            ProgressStore.guardarUltimoLibro(applicationContext, bookPath)

            handler.post {
                if (ttsListo) {
                    empezarLecturaDesdeIndiceActual()
                }
            }
        }.start()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val resultado = tts?.setLanguage(Locale("es", "ES"))
            if (resultado == TextToSpeech.LANG_MISSING_DATA || resultado == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.forLanguageTag("es"))
            }
            tts?.setSpeechRate(1.0f)
            ttsListo = true

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    handler.post {
                        ProgressStore.guardarProgreso(applicationContext, bookPath, indiceActual + 1)
                        indiceActual++
                        if (indiceActual < fragmentos.size && reproduciendo) {
                            hablarFragmentoActual()
                        } else if (indiceActual >= fragmentos.size) {
                            reproduciendo = false
                            enviarProgreso()
                            detener()
                        }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.post {
                        indiceActual++
                        if (indiceActual < fragmentos.size && reproduciendo) {
                            hablarFragmentoActual()
                        }
                    }
                }
            })

            if (fragmentos.isNotEmpty()) {
                empezarLecturaDesdeIndiceActual()
            }
        }
    }

    private fun empezarLecturaDesdeIndiceActual() {
        reproduciendo = true
        hablarFragmentoActual()
    }

    private fun hablarFragmentoActual() {
        if (fragmentos.isEmpty() || indiceActual >= fragmentos.size) return
        val texto = fragmentos[indiceActual]
        tts?.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "frag_$indiceActual")
        actualizarNotificacion(texto)
        enviarProgreso()
    }

    private fun pausar() {
        reproduciendo = false
        tts?.stop()
        ProgressStore.guardarProgreso(applicationContext, bookPath, indiceActual)
        enviarProgreso()
        actualizarNotificacion("En pausa")
    }

    private fun reanudar() {
        if (!reproduciendo) {
            reproduciendo = true
            hablarFragmentoActual()
        }
    }

    private fun detener() {
        reproduciendo = false
        tts?.stop()
        ProgressStore.guardarProgreso(applicationContext, bookPath, indiceActual)
        enviarProgreso()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun enviarProgreso() {
        val intent = Intent(BROADCAST_PROGRESO)
        intent.putExtra(EXTRA_FRAGMENTO_ACTUAL, indiceActual)
        intent.putExtra(EXTRA_TOTAL_FRAGMENTOS, fragmentos.size)
        intent.putExtra(EXTRA_TEXTO_FRAGMENTO, fragmentos.getOrNull(indiceActual) ?: "")
        intent.putExtra(EXTRA_REPRODUCIENDO, reproduciendo)
        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(intent)
    }

    private fun crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(
                CANAL_ID,
                "Lectura en voz alta",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(canal)
        }
    }

    private fun construirNotificacion(textoEstado: String): Notification {
        return NotificationCompat.Builder(this, CANAL_ID)
            .setContentTitle(bookTitulo.ifBlank { "Lector de Voz" })
            .setContentText(textoEstado)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun actualizarNotificacion(textoFragmento: String) {
        val resumen = textoFragmento.take(80).replace("\n", " ")
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIF_ID, construirNotificacion("Leyendo: $resumen…"))
    }

    override fun onDestroy() {
        ProgressStore.guardarProgreso(applicationContext, bookPath, indiceActual)
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
