package com.usuario.lectorvoz

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.util.zip.ZipFile

/**
 * Extrae el texto completo de un libro (txt, epub o pdf) para poder
 * partirlo en fragmentos y enviarlo al sintetizador de voz.
 */
object TextExtractor {

    fun extraerTexto(context: Context, book: Book): String {
        return when (book.format) {
            "txt" -> extraerTxt(book.path)
            "epub" -> extraerEpub(book.path)
            "pdf" -> extraerPdf(context, book.path)
            else -> ""
        }
    }

    private fun extraerTxt(path: String): String {
        return File(path).readText(Charsets.UTF_8)
    }

    private fun extraerEpub(path: String): String {
        val sb = StringBuilder()
        val zip = ZipFile(path)
        val entradas = zip.entries().toList()
            .filter { it.name.lowercase().let { n -> n.endsWith(".xhtml") || n.endsWith(".html") || n.endsWith(".htm") } }
            .sortedBy { it.name }

        for (entrada in entradas) {
            zip.getInputStream(entrada).use { input ->
                val html = input.readBytes().toString(Charsets.UTF_8)
                sb.append(limpiarHtml(html))
                sb.append("\n\n")
            }
        }
        zip.close()
        return sb.toString()
    }

    private fun limpiarHtml(html: String): String {
        var texto = html.replace(Regex("(?is)<script.*?</script>"), " ")
        texto = texto.replace(Regex("(?is)<style.*?</style>"), " ")
        texto = texto.replace(Regex("(?is)<(p|br|div|h[1-6]|li)[^>]*>"), "\n")
        texto = texto.replace(Regex("(?is)<[^>]+>"), " ")
        texto = texto.replace("&nbsp;", " ")
        texto = texto.replace("&amp;", "&")
        texto = texto.replace("&aacute;", "á").replace("&eacute;", "é")
            .replace("&iacute;", "í").replace("&oacute;", "ó").replace("&uacute;", "ú")
            .replace("&ntilde;", "ñ")
        texto = texto.replace(Regex("[ \\t]+"), " ")
        texto = texto.replace(Regex("\\n{3,}"), "\n\n")
        return texto.trim()
    }

    private fun extraerPdf(context: Context, path: String): String {
        PDFBoxResourceLoader.init(context.applicationContext)
        PDDocument.load(File(path)).use { documento ->
            val stripper = PDFTextStripper()
            return stripper.getText(documento)
        }
    }

    /**
     * Divide el texto en fragmentos aptos para TextToSpeech (que tiene un
     * límite práctico por cada utterance), intentando cortar en puntos o saltos
     * de línea para que la lectura suene natural.
     */
    fun dividirEnFragmentos(texto: String, tamanoMaximo: Int = 3500): List<String> {
        val fragmentos = mutableListOf<String>()
        var restante = texto.trim()

        while (restante.isNotEmpty()) {
            if (restante.length <= tamanoMaximo) {
                fragmentos.add(restante)
                break
            }
            var corte = restante.lastIndexOf('\n', tamanoMaximo)
            if (corte < tamanoMaximo / 2) {
                corte = restante.lastIndexOf(". ", tamanoMaximo)
            }
            if (corte < tamanoMaximo / 2) {
                corte = tamanoMaximo
            }
            fragmentos.add(restante.substring(0, corte).trim())
            restante = restante.substring(corte).trim()
        }
        return fragmentos.filter { it.isNotBlank() }
    }
}
